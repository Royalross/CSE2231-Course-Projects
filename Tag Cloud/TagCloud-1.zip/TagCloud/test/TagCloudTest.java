import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TagCloudTest {

    @Test
    // test when the character is 'h'
    // routine test
    public void isEnglishLetterTest1() {
        Character character = 'h';
        Character characterExpected = 'h';

        boolean isEnglishLetter = TagCloud.isEnglishLetter(character);
        boolean isEnglishLetterExpected = true;

        assertEquals(isEnglishLetterExpected, isEnglishLetter);
        assertEquals(characterExpected, character);

    }

    @Test
    // test when the character is '9'
    // routine test
    public void isEnglishLetterTest2() {
        Character character = '9';
        Character characterExpected = '9';

        boolean isEnglishLetter = TagCloud.isEnglishLetter(character);
        boolean isEnglishLetterExpected = false;

        assertEquals(isEnglishLetterExpected, isEnglishLetter);
        assertEquals(characterExpected, character);

    }

    @Test
    // test when the String is "Hello
    // routine test
    public void nextWordOrSeparatorTest1() {
        StringBuilder text = new StringBuilder("Hello");
        StringBuilder textExpected = new StringBuilder("Hello");

        String nextWordOrSeparator = TagCloud.nextWordOrSeparator(text);
        String nextWordOrSeparatorExpected = "Hello";

        assertEquals(nextWordOrSeparatorExpected, nextWordOrSeparator);
        assertEquals(textExpected.toString(), text.toString());

    }

    @Test
    // test when the String is "-  - -Hello"
    // routine test
    public void nextWordOrSeparatorTest2() {
        StringBuilder text = new StringBuilder("-  - -Hello");
        StringBuilder textExpected = new StringBuilder("-  - -Hello");

        String nextWordOrSeparator = TagCloud.nextWordOrSeparator(text);
        String nextWordOrSeparatorExpected = "-  - -";

        assertEquals(nextWordOrSeparatorExpected, nextWordOrSeparator);
        assertEquals(textExpected.toString(), text.toString());

    }

    @Test
    // test when the string is ""
    // base case test
    public void nextWordOrSeparatorTest3() {
        StringBuilder text = new StringBuilder("");
        StringBuilder textExpected = new StringBuilder("");

        String nextWordOrSeparator = TagCloud.nextWordOrSeparator(text);
        String nextWordOrSeparatorExpected = "";

        assertEquals(nextWordOrSeparatorExpected, nextWordOrSeparator);
        assertEquals(textExpected.toString(), text.toString());

    }

    @Test
    // test when the String is ".Hi -,."
    // difficult test
    public void nextWordOrSeparatorTest4() {
        StringBuilder text = new StringBuilder(".Hi -,.");
        StringBuilder textExpected = new StringBuilder(".Hi -,.");

        String nextWordOrSeparator = TagCloud.nextWordOrSeparator(text);
        String nextWordOrSeparatorExpected = ".";

        assertEquals(nextWordOrSeparatorExpected, nextWordOrSeparator);
        assertEquals(textExpected.toString(), text.toString());

    }

}
